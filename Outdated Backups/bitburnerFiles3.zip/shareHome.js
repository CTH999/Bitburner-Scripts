/** @param {NS} ns **/
export async function main(ns) {
    let buffer = ns.args[0];
    const minBuffer = 16;

		const target = "home";
    const script = "share0nce.js";
    if (!buffer) {
        ns.tprint(`No buffer provided, defaulting to a buffer of "${minBuffer}" gigs`);
        buffer = 16;
    } else if (buffer < minBuffer) {
			ns.tprint(`The Provided buffer of ${buffer} gig buffer was less than the minimum of ${minBuffer} gigs. Using ${minBuffer} gigs`);
			buffer = minBuffer;
		} else {
			ns.tprint(`Useing a buffer of "${buffer}" gigs`);
    }

    let maxRam = ns.getServerMaxRam(target);
    let usedRam = ns.getServerUsedRam(target);
    let scriptRam = ns.getScriptRam(script);    
    let threads = Math.floor((maxRam - (usedRam+buffer)) / scriptRam);

    if(threads <= 0) {
        ns.tprint(`Not Enough Room`);
        return;
    }
}