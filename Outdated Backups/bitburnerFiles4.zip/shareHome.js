/** @param {NS} ns **/
export async function main(ns) {

    let buffer = ns.args[0];
    const minBuffer = 16;

    const target = "home";
    const script = "shareOnce.js";

    if (!buffer) {
        ns.tprint(`No buffer provided, defaulting to ${minBuffer} GB`);
        buffer = minBuffer;
    } else if (buffer < minBuffer) {
        ns.tprint(`Buffer too small, using ${minBuffer} GB`);
        buffer = minBuffer;
    } else {
        ns.tprint(`Using buffer: ${buffer} GB`);
    }

    const scriptRam = ns.getScriptRam(script);

    while (true) {

        const maxRam = ns.getServerMaxRam(target);
        const usedRam = ns.getServerUsedRam(target);

        const freeRam = maxRam - usedRam - buffer;
        const threads = Math.floor(freeRam / scriptRam);

        //Exit condition (your "I'm done")
        if (threads <= 0) {
            ns.tprint("No more RAM available for share. Stopping.");
            return;
        }

        ns.print(`Running share with ${threads} threads`);

        const pid = ns.exec(script, target, threads);

        if (pid === 0) {
            ns.tprint("Failed to start share script (RAM race condition?)");
            return;
        }

        // Wait for this batch to finish
        while (ns.isRunning(pid)) {
            await ns.sleep(100);
        }
    }
}