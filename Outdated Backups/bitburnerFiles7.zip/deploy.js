/** @param {NS} ns **/
import { deploy } from "./deployer.js";

export async function main(ns) {

    const [script, target, threadsArg, fallbackArg] = ns.args;

    // ----------------------------
    // VALIDATION
    // ----------------------------

    if (!script || !target) {
        ns.tprint("Usage: run deploySingle.js SCRIPT TARGET [THREADS] [FALLBACK:y/n]");
        return;
    }

    if (!ns.fileExists(script, "home")) {
        ns.tprint(`Script "${script}" not found on home`);
        return;
    }

    if (!ns.serverExists(target)) {
        ns.tprint(`Server "${target}" is invalid`);
        return;
    }

    // ----------------------------
    // ARGUMENT PARSING
    // ----------------------------

    let threads = 1;
    if (threadsArg !== undefined) {
        threads = Number(threadsArg);

        if (isNaN(threads)) {
            ns.tprint(`Invalid thread count: "${threadsArg}"`);
            return;
        }
    }

    // default = no fallback
    let fallback = false;
    if (fallbackArg !== undefined) {
        fallback = String(fallbackArg).toLowerCase().startsWith("y");
    }

    // ----------------------------
    // DEPLOY
    // ----------------------------

    const result = deploy(ns, {
        script: script,
        target: target,
        threads: threads,
        fallback: fallback
    });

    ns.tprint(`[${target}] ${result?.message ?? "deploy failed"}`);
}