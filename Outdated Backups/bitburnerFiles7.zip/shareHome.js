/** @param {NS} ns **/
export async function main(ns) {

    let buffer = ns.args[0];
    const minBuffer = 16;

    const target = "home";
    const script = "shareOnce.js";

    if (!buffer) {
        ns.tprint(`No buffer provided, defaulting to ${minBuffer} GB`);
        buffer = minBuffer;
    } else if (buffer < minBuffer) {
        ns.tprint(`Buffer too small, using ${minBuffer} GB`);
        buffer = minBuffer;
    } else {
        ns.tprint(`Using buffer: ${buffer} GB`);
    }

    const scriptRam = ns.getScriptRam(script);

    if (scriptRam <= 0) {
        ns.tprint(`ERROR: Invalid RAM for ${script}`);
        return;
    }

    let failCount = 0;
    const retryDelay = 250;  // in miliseconds
    const maxFails = 6;  // 6 * 250ms = 1.5s  
    //tolerance window
    const tolerance = 12;

    while (true) {

        const maxRam = ns.getServerMaxRam(target);
        const usedRam = ns.getServerUsedRam(target);

        const freeRam = maxRam - (usedRam + buffer);
        const threads = Math.floor(freeRam / scriptRam);

        if (threads <= 0) {

            //simulate "what if we had a bit more RAM?"
            const testThreads = Math.floor((freeRam + tolerance) / scriptRam);

            if (testThreads > 0) {
                //likely temporary overlap
                ns.print(
                    `Near threshold | Free: ${freeRam.toFixed(2)} | Retrying (not counted)`
                );

                await ns.sleep(retryDelay);
                continue;
            }

            //real failure
            failCount++;

            ns.print(
                `Fail ${failCount}/${maxFails} | Free: ${freeRam.toFixed(2)}`
            );

            if (failCount >= maxFails) {
                ns.tprint("Not enough RAM (confirmed). Stopping.");
                return;
            }

            await ns.sleep(retryDelay);
        } else {

            //success path
            failCount = 0;

            ns.print(`Running share with ${threads} threads`);

            const pid = ns.exec(script, target, threads);

            if (pid === 0) {
                ns.tprint("Failed to start script (unexpected). Stopping.");
                return;
            }

            // wait for completion
            while (ns.isRunning(pid)) {
                await ns.sleep(100);
            }
        }
    }
}