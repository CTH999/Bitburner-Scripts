/** @param {NS} ns */
export async function main(ns) {
	ns.exec("autohack.js", "home");
	ns.exec("shareHome.js", "home", 1, 32);
}