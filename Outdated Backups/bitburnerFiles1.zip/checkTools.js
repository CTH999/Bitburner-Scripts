/** @param {NS} ns **/
export async function main(ns) {

    const YES = "YES";
    const NO = "NO";

    ns.tprint("=== PROGRAMS ===");

    const programs = [
        "BruteSSH.exe",
        "FTPCrack.exe",
        "relaySMTP.exe",
        "HTTPWorm.exe",
        "SQLInject.exe",
        "ServerProfiler.exe",
        "DeepscanV1.exe",
        "DeepscanV2.exe",
        "AutoLink.exe",
        "Formulas.exe"
    ];

    for (const prog of programs) {
        const owned = ns.fileExists(prog, "home");
        ns.tprint(`${prog}: ${owned ? YES : NO}`);
    }

    ns.tprint("\n=== STOCK ACCESS ===");

    let hasTIX = true;
    try {
        ns.stock.getSymbols();
    } catch {
        hasTIX = false;
    }

    let has4S = true;
    try {
        ns.stock.getForecast("ECP");
    } catch {
        has4S = false;
    }

    ns.tprint(`TIX API: ${hasTIX ? YES : NO}`);
    ns.tprint(`4S Data: ${has4S ? YES : NO}`);

    ns.tprint("\n=== OTHER ===");

    const hasTor = ns.scan("home").includes("darkweb");
    ns.tprint(`TOR Access: ${hasTor ? YES : NO}`);
}