/** @param {NS} ns **/
export async function main(ns) {
    const visited = new Set();
    const queue = ["home"];
    const data = {};

    while (queue.length > 0) {
        const server = queue.shift();

        if (visited.has(server)) continue;
        visited.add(server);

        // Skip home entirely
        if (server !== "home") {
            data[server] = {
                root: ns.hasRootAccess(server) ? 1 : 0,
                minHack: ns.getServerRequiredHackingLevel(server),
                ports: ns.getServerNumPortsRequired(server)
            };
        }

        const neighbors = ns.scan(server);
        for (const n of neighbors) {
            if (!visited.has(n)) {
                queue.push(n);
            }
        }
    }

    // Write JSON (overwrite mode "w")
    ns.write("servers.json", JSON.stringify(data, null, 2), "w");

    ns.tprint("Server data saved to servers.json");
}