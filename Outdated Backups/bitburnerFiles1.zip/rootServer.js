/** @param {NS} ns **/
export async function main(ns) {
    const server = ns.args[0];

    if (!server) return;

    if (ns.fileExists("BruteSSH.exe")) ns.brutessh(server);
    if (ns.fileExists("FTPCrack.exe")) ns.ftpcrack(server);
    if (ns.fileExists("relaySMTP.exe")) ns.relaysmtp(server);
    if (ns.fileExists("HTTPWorm.exe")) ns.httpworm(server);
    if (ns.fileExists("SQLInject.exe")) ns.sqlinject(server);

    try {
        ns.nuke(server);
        ns.tprint(`Rooted ${server}`);
    } catch {
        ns.tprint(`Failed to root ${server}`);
    }
}