/** @param {NS} ns **/
export async function main(ns) {

    // 1. Refresh server data
    ns.run("scanStatus.js");
    await ns.sleep(200);

    // 2. Generate hackable list
    ns.run("listHackable.js");
    await ns.sleep(200);

    const hackable = JSON.parse(ns.read("hackable.json") || "[]");

    if (hackable.length === 0) {
        ns.tprint("No hackable servers.");
        return;
    }

    let processed = [];

    for (const server of hackable) {

        // Root
        ns.run("rootServer.js", 1, server);
        await ns.sleep(50);

        // Deploy
        ns.run("deployAll.js", 1, server);

        processed.push(server);
    }

    // Refresh again
    ns.run("scanStatus.js");

    // Report
    ns.tprint("Processed servers:");
    for (const s of processed) {
        ns.tprint(" - " + s);
    }
}