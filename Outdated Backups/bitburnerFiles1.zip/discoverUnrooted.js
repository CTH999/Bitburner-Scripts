/** @param {NS} ns **/
export async function main(ns) {
    const visited = new Set();
    const queue = ["home"];

    const noRoot = [];

    while (queue.length > 0) {
        const server = queue.shift();

        if (visited.has(server)) continue;
        visited.add(server);

        // Check root access
        if (!ns.hasRootAccess(server)) {
            noRoot.push(server);
        }

        // Scan neighbors
        const neighbors = ns.scan(server);
        for (const n of neighbors) {
            if (!visited.has(n)) {
                queue.push(n);
            }
        }
    }

    // Print results
    if (noRoot.length === 0) {
        ns.tprint("All discovered servers have root access.");
    } else {
        ns.tprint("Servers WITHOUT root access:");
        for (const s of noRoot) {
            ns.tprint(" - " + s);
        }
    }
}