/** @param {NS} ns **/
export async function main(ns) {
    let target = ns.args[0];

    if (!target) {
        ns.tprint("Usage: run controller.js SERVER");
        return;
    }

    let script = "share.js";

    await ns.scp(script, target);

    let maxRam = ns.getServerMaxRam(target);
    let usedRam = ns.getServerUsedRam(target);
    let scriptRam = ns.getScriptRam(script);

    let threads = Math.floor((maxRam - usedRam) / scriptRam);
    if(threads <= 0) {
        ns.tprint(`Not Enough Room`);
        return;
    }
        ns.tprint(`Running "${threads}" iterations of share.js`);
        ns.exec(script, target, threads);
}