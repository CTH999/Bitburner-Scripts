/** @param {NS} ns **/
export async function main(ns) {

    const target = ns.args[0];

    if (!target) {
        ns.tprint("Usage: run deploy.js SERVER");
        return;
    }

    if (!ns.serverExists(target)) {
        ns.tprint(`SERVER "${target}" is invalid`);
        return;
    }

    const scripts = ["basic.js", "grow.js", "weaken.js"];
    const home = "home";

    let results = [];

    for (const script of scripts) {
        const result = await deployOne(ns, script, target, home);
        results.push(result);
    }

    ns.tprint(`[${target}] ${results.join(" | ")}`);
}

async function deployOne(ns, script, target, home) {

    const threads = 1;
    const scriptRam = ns.getScriptRam(script);

    // TRY TARGET
    if (ns.hasRootAccess(target)) {

        if (ns.isRunning(script, target, target)) {
            return `${script}: already`;
        }

        const freeRam =
            ns.getServerMaxRam(target) - ns.getServerUsedRam(target);

        if (freeRam >= scriptRam) {
            await ns.scp(script, target);
            ns.exec(script, target, threads, target);
            return `${script}: target`;
        }
    }

    // FALLBACK HOME
    if (ns.isRunning(script, home, target)) {
        return `${script}: home(already)`;
    }

    const controllerRam = ns.getScriptRam("deployAll.js");
    const buffer = 5;

    const freeRam =
        ns.getServerMaxRam(home)
        - ns.getServerUsedRam(home)
        - controllerRam
        - buffer;

    if (freeRam < scriptRam) {
        return `${script}: no-ram`;
    }

    ns.exec(script, home, threads, target);
    return `${script}: home`;
}