/** @param {NS} ns **/
export async function main(ns) {

    const data = JSON.parse(ns.read("servers.json"));

    let portsAvailable = 0;
    if (ns.fileExists("BruteSSH.exe")) portsAvailable++;
    if (ns.fileExists("FTPCrack.exe")) portsAvailable++;
    if (ns.fileExists("relaySMTP.exe")) portsAvailable++;
    if (ns.fileExists("HTTPWorm.exe")) portsAvailable++;
    if (ns.fileExists("SQLInject.exe")) portsAvailable++;

    const playerLevel = ns.getHackingLevel();

    let hackable = [];

    for (const server in data) {
        const info = data[server];

        if (info.root === 1) continue;

        if (portsAvailable >= info.ports && playerLevel >= info.minHack) {
            hackable.push(server);
        }
    }

    ns.write("hackable.json", JSON.stringify(hackable), "w");
}