/** @param {NS} ns */
export async function main(ns) {
    ns.tprint("deployer.js is a library. Do not run directly.");
    return;
}

/** deployer.js - workload allocation utility **/
export function deploy(ns, config) {
    const {
        script,
        target,
        threads = 1,
        fallback = true
    } = config;

    if (!script || !target) {
        return {
            mode: "error",
            message: "deploy(): missing script or target"
        };
    }

    const home = "home";
    const scriptRam = ns.getScriptRam(script);

    function maxThreads(host) {
        const freeRam =
            ns.getServerMaxRam(host) -
            ns.getServerUsedRam(host);

        if (freeRam <= 0 || scriptRam <= 0) return 0;
        return Math.floor(freeRam / scriptRam);
    }

    let requested = threads;

    // -------------------------
    // MODE: FILL TARGET ONLY
    // -------------------------
    if (threads === -1) {
        const targetCap = maxThreads(target);

        if (targetCap <= 0) {
            return {
                mode: "fill",
                message: "no room on target"
            };
        }

        ns.scp(script, target);
        const pid = ns.exec(script, target, targetCap, target);

        if (!pid) {
            return {
                mode: "error",
                message: `FAILED to exec ${script} on ${target}`
            };
        }

        return {
            mode: "fill",
            message: `${script}: ran ${targetCap} on target`
        };
    }

    // -------------------------
    // TARGET ALLOCATION
    // -------------------------
    let targetThreads = 0;

    if (ns.hasRootAccess(target)) {
        const targetCap = maxThreads(target);
        targetThreads = Math.min(requested, targetCap);

        if (targetThreads > 0) {
            ns.scp(script, target);
            const pid = ns.exec(script, target, targetThreads, target);

            if (!pid) {
                return {
                    mode: "error",
                    message: `FAILED to exec ${script} on target ${target}`
                };
            }
        }
    }

    let remaining = requested - targetThreads;

    // -------------------------
    // PURCHASED SERVER FALLBACK
    // -------------------------
    let purchasedUsed = [];

    if (fallback && remaining > 0) {
        const servers = ns.cloud.getServerNames();

        for (const server of servers) {
            if (remaining <= 0) break;

            const cap = maxThreads(server);
            if (cap <= 0) continue;

            const use = Math.min(cap, remaining);

            ns.scp(script, server);
            const pid = ns.exec(script, server, use, target);

            if (!pid) continue;

            purchasedUsed.push(`${server}:${use}`);
            remaining -= use;
        }
    }

    // -------------------------
    // HOME FALLBACK
    // -------------------------
    let homeThreads = 0;

    if (fallback && remaining > 0) {
        const homeCap = maxThreads(home);
        homeThreads = Math.min(homeCap, remaining);

        if (homeThreads > 0) {
            const pid = ns.exec(script, home, homeThreads, target);

            if (!pid) {
                return {
                    mode: "error",
                    message: `FAILED to exec ${script} on home`
                };
            }

            remaining -= homeThreads;
        }
    }

    // -------------------------
    // REPORTING (human-readable)
    // -------------------------

    let parts = [];

    if (targetThreads > 0) {
        parts.push(`ran ${targetThreads} on target`);
    }

    // sum purchased usage
    let totalPserv = 0;
    for (const entry of purchasedUsed) {
        const [, count] = entry.split(":");
        totalPserv += Number(count);
    }

    if (totalPserv > 0) {
        parts.push(`ran ${totalPserv} on fallback servers`);
    }

    if (homeThreads > 0) {
        parts.push(`ran ${homeThreads} on home fallback`);
    }

    if (remaining > 0) {
        parts.push(`could not deploy ${remaining}`);
    }

    if (parts.length === 0) {
        parts.push("no execution possible");
    }

    return {
        mode: "split",
        message: `${script}: ${parts.join(", ")}`
    };
}